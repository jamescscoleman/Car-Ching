import React from 'react';
import {Text} from 'react-native';
import {useStyles, createStyles} from 'styles';

export interface BrakingProps {
  property1: 'Default' | 'Variant3',
  testID?: string,
}

export function Braking(props: BrakingProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant3 = props.property1 === 'Variant3';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant3 && styles.rootProperty1Variant3,
    ],
    rectangle4128: [
      styles.rectangle4128,
      _property1Variant3 && styles.rectangle4128Property1Variant3,
    ],
    rectangle4129: [
      styles.rectangle4129,
      _property1Variant3 && styles.rectangle4129Property1Variant3,
    ],
    brakingThatIsFarHarderThanTypicallyNeeded: [
      styles.brakingThatIsFarHarderThanTypicallyNeeded,
      _property1Variant3 && styles.brakingThatIsFarHarderThanTypicallyNeededProperty1Variant3,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <View style={$styles.rectangle4128} testID="1789:2602"/>
      <View style={$styles.rectangle4129} testID="1789:2603"/>
      <Text style={styles.excellentHarshBraking} testID="1789:2612">
        {`Excellent
Harsh Braking `}
      </Text>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 151,
    height: 54,
    flexShrink: 0,
  },
  rectangle4128: {
    width: 151,
    height: 54,
    flexShrink: 0,
    borderRadius: 7,
    backgroundColor: 'rgba(225, 232, 249, 1)',
  },
  rectangle4129: {
    width: 9,
    height: 54,
    flexShrink: 0,
    borderRadius: 3,
    backgroundColor: 'rgba(0, 130, 85, 1)',
  },
  excellentHarshBraking: {
    width: 142,
    height: 54,
    flexShrink: 0,
    color: 'rgba(120, 112, 112, 1)',
    textAlign: 'center',
    fontFamily: 'Roboto',
    fontSize: 16,
    fontStyle: 'normal',
    fontWeight: '400',
    lineHeight: 23,
    letterSpacing: 0.5,
  },
}));
