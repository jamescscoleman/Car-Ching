import React from 'react';
import {View} from 'react-native';
import {useStyles, createStyles} from 'styles';

export interface MenuProps {
  testID?: string,
}

export function Menu(props: MenuProps) {
  const {styles} = useStyles(stylesheet);

  return (
    <View style={styles.root} testID={props.testID}>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 24,
    height: 5,
    flexShrink: 0,
  },
}));
