import {Menu as Component} from './Menu';
import type {StoryObj, Meta} from '@storybook/react';

type Story = StoryObj<typeof Component>;

const meta: Meta<typeof Component> = {
  title: 'Menu',
  component: Component,
};

export const Menu: Story = {
  // ...
};

export default meta;
