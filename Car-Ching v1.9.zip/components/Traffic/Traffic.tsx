import React from 'react';
import {Text} from 'react-native';
import {useStyles, createStyles} from 'styles';

export interface TrafficProps {
  property1: 'Default' | 'Variant3',
  testID?: string,
}

export function Traffic(props: TrafficProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant3 = props.property1 === 'Variant3';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant3 && styles.rootProperty1Variant3,
    ],
    rectangle4132: [
      styles.rectangle4132,
      _property1Variant3 && styles.rectangle4132Property1Variant3,
    ],
    rectangle4133: [
      styles.rectangle4133,
      _property1Variant3 && styles.rectangle4133Property1Variant3,
    ],
    trafficViolationsLikeRunningStopSigns: [
      styles.trafficViolationsLikeRunningStopSigns,
      _property1Variant3 && styles.trafficViolationsLikeRunningStopSignsProperty1Variant3,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <View style={$styles.rectangle4132} testID="1789:2608"/>
      <View style={$styles.rectangle4133} testID="1789:2609"/>
      <Text style={styles.fairTrafficViolations} testID="1789:2617">
        {`Fair
Traffic Violations`}
      </Text>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 151,
    height: 54,
    flexShrink: 0,
  },
  rectangle4132: {
    width: 151,
    height: 54,
    flexShrink: 0,
    borderRadius: 7,
    backgroundColor: 'rgba(225, 232, 249, 1)',
  },
  rectangle4133: {
    width: 9,
    height: 54,
    flexShrink: 0,
    borderRadius: 3,
    backgroundColor: 'rgba(248, 187, 50, 1)',
  },
  fairTrafficViolations: {
    width: 142,
    height: 54,
    flexShrink: 0,
    color: 'rgba(120, 112, 112, 1)',
    textAlign: 'center',
    fontFamily: 'Roboto',
    fontSize: 16,
    fontStyle: 'normal',
    fontWeight: '400',
    lineHeight: 23,
    letterSpacing: 0.5,
  },
}));
