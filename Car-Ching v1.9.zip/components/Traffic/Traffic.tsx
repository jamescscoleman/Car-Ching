import React from 'react';
import {Text} from 'react-native';
import {useStyles, createStyles} from 'styles';

export interface TrafficProps {
  property1: 'Default' | 'Variant2',
  testID?: string,
}

export function Traffic(props: TrafficProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant2 = props.property1 === 'Variant2';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant2 && styles.rootProperty1Variant2,
    ],
    rectangle4132: [
      styles.rectangle4132,
      _property1Variant2 && styles.rectangle4132Property1Variant2,
    ],
    rectangle4133: [
      styles.rectangle4133,
      _property1Variant2 && styles.rectangle4133Property1Variant2,
    ],
    trafficViolationsLikeRunningStopSigns: [
      styles.trafficViolationsLikeRunningStopSigns,
      _property1Variant2 && styles.trafficViolationsLikeRunningStopSignsProperty1Variant2,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <View style={$styles.rectangle4132} testID="2500:872"/>
      <View style={$styles.rectangle4133} testID="2500:873"/>
      <Text style={styles.fairTrafficViolations} testID="2500:874">
        {`Traffic Violations`}
      </Text>
      <Text style={styles.fair} testID="2500:857">
        {`Fair`}
      </Text>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 318,
    height: 54,
    flexShrink: 0,
    borderRadius: 15,
  },
  rectangle4132: {
    width: 318,
    height: 54,
    flexShrink: 0,
    borderRadius: 7,
    backgroundColor: 'rgba(225, 232, 249, 1)',
  },
  rectangle4133: {
    width: 18.954,
    height: 54,
    flexShrink: 0,
    borderRadius: 7,
    backgroundColor: 'rgba(248, 187, 50, 1)',
  },
  fairTrafficViolations: {
    width: 299.04599,
    height: 54,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(120, 112, 112, 1)',
    fontFamily: 'Roboto',
    fontSize: 16,
    fontStyle: 'normal',
    fontWeight: '400',
    lineHeight: 23,
    letterSpacing: 0.5,
  },
  fair: {
    width: 98,
    height: 54,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(120, 112, 112, 1)',
    textAlign: 'center',
    fontFamily: 'Roboto',
    fontSize: 16,
    fontStyle: 'normal',
    fontWeight: '400',
    lineHeight: 23,
    letterSpacing: 0.5,
  },
}));
