import React from 'react';
import {Text} from 'react-native';
import {useStyles, createStyles} from 'styles';

export interface CorneringProps {
  property1: 'Default' | 'Variant3',
  testID?: string,
}

export function Cornering(props: CorneringProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant3 = props.property1 === 'Variant3';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant3 && styles.rootProperty1Variant3,
    ],
    rectangle4136: [
      styles.rectangle4136,
      _property1Variant3 && styles.rectangle4136Property1Variant3,
    ],
    rectangle4130: [
      styles.rectangle4130,
      _property1Variant3 && styles.rectangle4130Property1Variant3,
    ],
    turningACornerTooFast: [
      styles.turningACornerTooFast,
      _property1Variant3 && styles.turningACornerTooFastProperty1Variant3,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <View style={$styles.rectangle4136} testID="1789:2604"/>
      <View style={$styles.rectangle4130} testID="1789:2605"/>
      <Text style={styles.fairCornering} testID="1789:2618">
        {`Fair
Cornering`}
      </Text>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 151,
    height: 54,
    flexShrink: 0,
  },
  rectangle4136: {
    width: 151,
    height: 54,
    flexShrink: 0,
    borderRadius: 7,
    backgroundColor: 'rgba(225, 232, 249, 1)',
  },
  rectangle4130: {
    width: 9,
    height: 54,
    flexShrink: 0,
    borderRadius: 3,
    backgroundColor: 'rgba(248, 187, 50, 1)',
  },
  fairCornering: {
    width: 142,
    height: 54,
    flexShrink: 0,
    color: 'rgba(120, 112, 112, 1)',
    textAlign: 'center',
    fontFamily: 'Roboto',
    fontSize: 16,
    fontStyle: 'normal',
    fontWeight: '400',
    lineHeight: 23,
    letterSpacing: 0.5,
  },
}));
