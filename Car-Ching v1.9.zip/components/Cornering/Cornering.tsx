import React from 'react';
import {Text} from 'react-native';
import {useStyles, createStyles} from 'styles';

export interface CorneringProps {
  property1: 'Default' | 'Variant2',
  testID?: string,
}

export function Cornering(props: CorneringProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant2 = props.property1 === 'Variant2';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant2 && styles.rootProperty1Variant2,
    ],
    rectangle4136: [
      styles.rectangle4136,
      _property1Variant2 && styles.rectangle4136Property1Variant2,
    ],
    rectangle4130: [
      styles.rectangle4130,
      _property1Variant2 && styles.rectangle4130Property1Variant2,
    ],
    turningACornerTooFast: [
      styles.turningACornerTooFast,
      _property1Variant2 && styles.turningACornerTooFastProperty1Variant2,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <View style={$styles.rectangle4136} testID="2500:860"/>
      <View style={$styles.rectangle4130} testID="2500:861"/>
      <Text style={styles.fairCornering} testID="2500:862">
        {`Cornering`}
      </Text>
      <Text style={styles.fair} testID="2500:858">
        {`Fair`}
      </Text>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 318,
    height: 54,
    flexShrink: 0,
    borderRadius: 15,
  },
  rectangle4136: {
    width: 318,
    height: 54,
    flexShrink: 0,
    borderRadius: 7,
    backgroundColor: 'rgba(225, 232, 249, 1)',
  },
  rectangle4130: {
    width: 18.954,
    height: 54,
    flexShrink: 0,
    borderRadius: 7,
    backgroundColor: 'rgba(248, 187, 50, 1)',
  },
  fairCornering: {
    width: 299.04599,
    height: 54,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(120, 112, 112, 1)',
    fontFamily: 'Roboto',
    fontSize: 16,
    fontStyle: 'normal',
    fontWeight: '400',
    lineHeight: 23,
    letterSpacing: 0.5,
  },
  fair: {
    width: 98,
    height: 54,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(120, 112, 112, 1)',
    textAlign: 'center',
    fontFamily: 'Roboto',
    fontSize: 16,
    fontStyle: 'normal',
    fontWeight: '400',
    lineHeight: 23,
    letterSpacing: 0.5,
  },
}));
