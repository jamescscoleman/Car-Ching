import React from 'react';
import {Text} from 'react-native';
import {useStyles, createStyles} from 'styles';

export interface SpeedingProps {
  property1: 'Default' | 'Variant2',
  testID?: string,
}

export function Speeding(props: SpeedingProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant2 = props.property1 === 'Variant2';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant2 && styles.rootProperty1Variant2,
    ],
    rectangle4123: [
      styles.rectangle4123,
      _property1Variant2 && styles.rectangle4123Property1Variant2,
    ],
    rectangle4124: [
      styles.rectangle4124,
      _property1Variant2 && styles.rectangle4124Property1Variant2,
    ],
    continuouslyDrivingFarAboveTheSpeedLimit: [
      styles.continuouslyDrivingFarAboveTheSpeedLimit,
      _property1Variant2 && styles.continuouslyDrivingFarAboveTheSpeedLimitProperty1Variant2,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <View style={$styles.rectangle4123} testID="2500:876"/>
      <View style={$styles.rectangle4124} testID="2500:877"/>
      <Text style={styles.goodSpeeding} testID="2500:878">
        {`Speeding `}
      </Text>
      <Text style={styles.good} testID="2500:854">
        {`Good`}
      </Text>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 318,
    height: 54,
    flexShrink: 0,
    borderRadius: 15,
  },
  rectangle4123: {
    width: 318,
    height: 54,
    flexShrink: 0,
    borderRadius: 7,
    backgroundColor: 'rgba(225, 232, 249, 1)',
  },
  rectangle4124: {
    width: 18.954,
    height: 54,
    flexShrink: 0,
    borderRadius: 7,
    backgroundColor: 'rgba(146, 212, 199, 1)',
  },
  goodSpeeding: {
    width: 299.04599,
    height: 54,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(120, 112, 112, 1)',
    fontFamily: 'Roboto',
    fontSize: 16,
    fontStyle: 'normal',
    fontWeight: '400',
    lineHeight: 23,
    letterSpacing: 0.5,
  },
  good: {
    width: 98,
    height: 54,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(120, 112, 112, 1)',
    textAlign: 'center',
    fontFamily: 'Roboto',
    fontSize: 16,
    fontStyle: 'normal',
    fontWeight: '400',
    lineHeight: 23,
    letterSpacing: 0.5,
  },
}));
