import React from 'react';
import {Text} from 'react-native';
import {useStyles, createStyles} from 'styles';

export interface SpeedingProps {
  property1: 'Default' | 'Variant3',
  testID?: string,
}

export function Speeding(props: SpeedingProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant3 = props.property1 === 'Variant3';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant3 && styles.rootProperty1Variant3,
    ],
    rectangle4123: [
      styles.rectangle4123,
      _property1Variant3 && styles.rectangle4123Property1Variant3,
    ],
    rectangle4124: [
      styles.rectangle4124,
      _property1Variant3 && styles.rectangle4124Property1Variant3,
    ],
    continuouslyDrivingFarAboveTheSpeedLimit: [
      styles.continuouslyDrivingFarAboveTheSpeedLimit,
      _property1Variant3 && styles.continuouslyDrivingFarAboveTheSpeedLimitProperty1Variant3,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <View style={$styles.rectangle4123} testID="1789:2613"/>
      <View style={$styles.rectangle4124} testID="1789:2614"/>
      <Text style={styles.goodSpeeding} testID="1789:2615">
        {`Good
Speeding `}
      </Text>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 151,
    height: 54,
    flexShrink: 0,
  },
  rectangle4123: {
    width: 151,
    height: 54,
    flexShrink: 0,
    borderRadius: 7,
    backgroundColor: 'rgba(225, 232, 249, 1)',
  },
  rectangle4124: {
    width: 9,
    height: 54,
    flexShrink: 0,
    borderRadius: 3,
    backgroundColor: 'rgba(146, 212, 199, 1)',
  },
  goodSpeeding: {
    width: 142,
    height: 54,
    flexShrink: 0,
    color: 'rgba(120, 112, 112, 1)',
    textAlign: 'center',
    fontFamily: 'Roboto',
    fontSize: 16,
    fontStyle: 'normal',
    fontWeight: '400',
    lineHeight: 23,
    letterSpacing: 0.5,
  },
}));
