import React from 'react';
import {Text} from 'react-native';
import {useStyles, createStyles} from 'styles';

export interface AccelerationProps {
  property1: 'Default' | 'Variant3',
  testID?: string,
}

export function Acceleration(props: AccelerationProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant3 = props.property1 === 'Variant3';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant3 && styles.rootProperty1Variant3,
    ],
    rectangle4134: [
      styles.rectangle4134,
      _property1Variant3 && styles.rectangle4134Property1Variant3,
    ],
    rectangle4135: [
      styles.rectangle4135,
      _property1Variant3 && styles.rectangle4135Property1Variant3,
    ],
    rapidAcceleratingRatherThanGradually: [
      styles.rapidAcceleratingRatherThanGradually,
      _property1Variant3 && styles.rapidAcceleratingRatherThanGraduallyProperty1Variant3,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <View style={$styles.rectangle4134} testID="1789:2610"/>
      <View style={$styles.rectangle4135} testID="1789:2611"/>
      <Text style={styles.poorRapidAcceleration} testID="1789:2619">
        {`Poor
Rapid Acceleration`}
      </Text>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 151,
    height: 54,
    flexShrink: 0,
  },
  rectangle4134: {
    width: 151,
    height: 54,
    flexShrink: 0,
    borderRadius: 7,
    backgroundColor: 'rgba(225, 232, 249, 1)',
  },
  rectangle4135: {
    width: 9,
    height: 54,
    flexShrink: 0,
    borderRadius: 3,
    backgroundColor: 'rgba(255, 92, 92, 1)',
  },
  poorRapidAcceleration: {
    width: 142,
    height: 54,
    flexShrink: 0,
    color: 'rgba(120, 112, 112, 1)',
    textAlign: 'center',
    fontFamily: 'Roboto',
    fontSize: 16,
    fontStyle: 'normal',
    fontWeight: '400',
    lineHeight: 23,
    letterSpacing: 0.5,
  },
}));
