import {Time3 as Component} from './Time3';
import type {StoryObj, Meta} from '@storybook/react';

type Story = StoryObj<typeof Component>;

const meta: Meta<typeof Component> = {
  title: 'Time3',
  component: Component,
};

export const Default: Story = {
  args: {
    property1: 'Default',
  },
};

export const Variant2: Story = {
  args: {
    property1: 'Variant2',
  },
};

export const Variant3: Story = {
  args: {
    property1: 'Variant3',
  },
};

export default meta;
