import React from 'react';
import {Text} from 'react-native';
import {useStyles, createStyles} from 'styles';
import Rectangle4121 from 'assets/vectors/Rectangle4121.svg';
import Rectangle4122 from 'assets/vectors/Rectangle4122.svg';

export interface Time3Props {
  property1: 'Default' | 'Variant2' | 'Variant3',
  testID?: string,
}

export function Time3(props: Time3Props) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant2 = props.property1 === 'Variant2';
  const _property1Variant3 = props.property1 === 'Variant3';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant2 && styles.rootProperty1Variant2,
      _property1Variant3 && styles.rootProperty1Variant3,
    ],
    week: [
      styles.week,
      _property1Variant2 && styles.weekProperty1Variant2,
      _property1Variant3 && styles.weekProperty1Variant3,
    ],
    allTime: [
      styles.allTime,
      _property1Variant2 && styles.allTimeProperty1Variant2,
      _property1Variant3 && styles.allTimeProperty1Variant3,
    ],
    month: [
      styles.month,
      _property1Variant2 && styles.monthProperty1Variant2,
      _property1Variant3 && styles.monthProperty1Variant3,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <Rectangle4121/>
      <Rectangle4122/>
      <Text style={$styles.week} testID="1791:3014">
        {`Week`}
      </Text>
      <Text style={$styles.allTime} testID="1791:3015">
        {`All Time`}
      </Text>
      <Text style={$styles.month} testID="1791:3021">
        {`Month`}
      </Text>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 360,
    height: 48,
    flexShrink: 0,
  },
  rootProperty1Variant3: {
    width: 'unset',
    height: 'unset',
    flexShrink: 'unset',
    flexDirection: 'column',
    alignItems: 'flex-start',
    rowGap: 10,
    columnGap: 10,
  },
  week: {
    width: 120,
    height: 18,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(255, 255, 255, 1)',
    textAlign: 'center',
    fontFamily: 'Open Sans',
    fontSize: 12,
    fontStyle: 'normal',
    fontWeight: '700',
    lineHeight: 15,
  },
  weekProperty1Variant2: {
    color: 'rgba(181, 181, 181, 1)',
  },
  weekProperty1Variant3: {
    flexShrink: 'unset',
    top: 15,
    color: 'rgba(181, 181, 181, 1)',
  },
  allTime: {
    width: 120,
    height: 18,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(181, 181, 181, 1)',
    textAlign: 'center',
    fontFamily: 'Open Sans',
    fontSize: 12,
    fontStyle: 'normal',
    fontWeight: '700',
    lineHeight: 15,
  },
  allTimeProperty1Variant3: {
    flexShrink: 'unset',
    right: 0,
    top: 15,
    color: 'rgba(255, 255, 255, 1)',
  },
  month: {
    width: 120,
    height: 18,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(181, 181, 181, 1)',
    textAlign: 'center',
    fontFamily: 'Open Sans',
    fontSize: 12,
    fontStyle: 'normal',
    fontWeight: '700',
    lineHeight: 15,
  },
  monthProperty1Variant2: {
    color: 'rgba(255, 255, 255, 1)',
  },
  monthProperty1Variant3: {
    flexShrink: 'unset',
    left: 120,
    top: 15,
  },
}));
