import React from 'react';
import {View} from 'react-native';
import {useStyles, createStyles} from 'styles';
import {TimerButton} from 'components/TimerButton';

export interface TimerButtonProps {
  property1: 'Default' | 'Variant2',
  testID?: string,
}

export function TimerButton(props: TimerButtonProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant2 = props.property1 === 'Variant2';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant2 && styles.rootProperty1Variant2,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <TimerButton state="Default" text={`I haven’t received a code `} testID="1710:2418"/>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
}));
