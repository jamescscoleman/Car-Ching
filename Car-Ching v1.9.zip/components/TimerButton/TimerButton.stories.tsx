import {TimerButton as Component} from './TimerButton';
import type {StoryObj, Meta} from '@storybook/react';

type Story = StoryObj<typeof Component>;

const meta: Meta<typeof Component> = {
  title: 'Timer Button',
  component: Component,
};

export const Default: Story = {
  args: {
    property1: 'Default',
  },
};

export const Variant2: Story = {
  args: {
    property1: 'Variant2',
  },
};

export default meta;
