import React from 'react';
import {Text} from 'react-native';
import {useStyles, createStyles} from 'styles';
import Rectangle4121 from 'assets/vectors/Rectangle4121.svg';
import Rectangle4122 from 'assets/vectors/Rectangle4122.svg';

export interface YouVsCircleProps {
  property1: 'Default' | 'Variant2',
  testID?: string,
}

export function YouVsCircle(props: YouVsCircleProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant2 = props.property1 === 'Variant2';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant2 && styles.rootProperty1Variant2,
    ],
    you: [
      styles.you,
      _property1Variant2 && styles.youProperty1Variant2,
    ],
    family: [
      styles.family,
      _property1Variant2 && styles.familyProperty1Variant2,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <Rectangle4121/>
      <Rectangle4122/>
      <Text style={$styles.you} testID="1751:2504">
        {`You`}
      </Text>
      <Text style={$styles.family} testID="1751:2505">
        {`Family`}
      </Text>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 243.429,
    height: 48,
    flexShrink: 0,
  },
  you: {
    width: 124.198,
    height: 17.388,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(255, 255, 255, 1)',
    textAlign: 'center',
    fontFamily: 'Open Sans',
    fontSize: 12,
    fontStyle: 'normal',
    fontWeight: '700',
    lineHeight: 15,
  },
  youProperty1Variant2: {
    color: 'rgba(181, 181, 181, 1)',
  },
  family: {
    width: 125.143,
    height: 17.143,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(181, 181, 181, 1)',
    textAlign: 'center',
    fontFamily: 'Open Sans',
    fontSize: 12,
    fontStyle: 'normal',
    fontWeight: '700',
    lineHeight: 15,
  },
  familyProperty1Variant2: {
    color: 'rgba(255, 255, 255, 1)',
  },
}));
