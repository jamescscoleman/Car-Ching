import {Time as Component} from './Time';
import type {StoryObj, Meta} from '@storybook/react';

type Story = StoryObj<typeof Component>;

const meta: Meta<typeof Component> = {
  title: 'Time',
  component: Component,
};

export const Variant3: Story = {
  args: {
    property1: 'Variant3',
  },
};

export const Variant2: Story = {
  args: {
    property1: 'Variant2',
  },
};

export const Default: Story = {
  args: {
    property1: 'Default',
  },
};

export default meta;
