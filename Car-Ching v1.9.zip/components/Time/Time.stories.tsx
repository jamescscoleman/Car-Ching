import {Time as Component} from './Time';
import type {StoryObj, Meta} from '@storybook/react';

type Story = StoryObj<typeof Component>;

const meta: Meta<typeof Component> = {
  title: 'Time',
  component: Component,
};

export const DefaultDefault: Story = {
  args: {
    property1: 'DefaultDefault',
    property2: 'DefaultDefault',
  },
};

export const Variant2Default: Story = {
  args: {
    property1: 'Variant2Default',
    property2: 'Variant2Default',
  },
};

export default meta;
