import React from 'react';
import {Text} from 'react-native';
import {useStyles, createStyles} from 'styles';
import Rectangle4121 from 'assets/vectors/Rectangle4121.svg';
import Rectangle4122 from 'assets/vectors/Rectangle4122.svg';

export interface TimeProps {
  property1: 'Default' | 'Variant2',
  property2: 'Default',
  testID?: string,
}

export function Time(props: TimeProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant2 = props.property1 === 'Variant2';
  const _property2Default = props.property2 === 'Default';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant2 && _property2Default && styles.rootProperty1Variant2Property2Default,
    ],
    month: [
      styles.month,
      _property1Variant2 && _property2Default && styles.monthProperty1Variant2Property2Default,
    ],
    allTime: [
      styles.allTime,
      _property1Variant2 && _property2Default && styles.allTimeProperty1Variant2Property2Default,
    ],
  }), [styles, props.property1, props.property2]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <Rectangle4121/>
      <Rectangle4122/>
      <Text style={$styles.month} testID="1321:1259">
        {`Month`}
      </Text>
      <Text style={$styles.allTime} testID="1321:1260">
        {`All Time`}
      </Text>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 243.429,
    height: 48,
    flexShrink: 0,
  },
  month: {
    width: 124.198,
    height: 17.388,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(255, 255, 255, 1)',
    textAlign: 'center',
    fontFamily: 'Open Sans',
    fontSize: 12,
    fontStyle: 'normal',
    fontWeight: '700',
    lineHeight: 15,
  },
  monthProperty1Variant2Property2Default: {
    color: 'rgba(181, 181, 181, 1)',
  },
  allTime: {
    width: 125.143,
    height: 17.143,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(181, 181, 181, 1)',
    textAlign: 'center',
    fontFamily: 'Open Sans',
    fontSize: 12,
    fontStyle: 'normal',
    fontWeight: '700',
    lineHeight: 15,
  },
  allTimeProperty1Variant2Property2Default: {
    color: 'rgba(255, 255, 255, 1)',
  },
}));
