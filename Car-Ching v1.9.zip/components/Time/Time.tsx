import React from 'react';
import {Text} from 'react-native';
import {useStyles, createStyles} from 'styles';

export interface TimeProps {
  property1: 'Default' | 'Variant2' | 'Variant3',
  testID?: string,
}

export function Time(props: TimeProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant2 = props.property1 === 'Variant2';
  const _property1Variant3 = props.property1 === 'Variant3';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant3 && styles.rootProperty1Variant3,
      _property1Variant2 && styles.rootProperty1Variant2,
    ],
    week: [
      styles.week,
      _property1Variant3 && styles.weekProperty1Variant3,
      _property1Variant2 && styles.weekProperty1Variant2,
    ],
    month: [
      styles.month,
      _property1Variant3 && styles.monthProperty1Variant3,
      _property1Variant2 && styles.monthProperty1Variant2,
    ],
    allTime: [
      styles.allTime,
      _property1Variant3 && styles.allTimeProperty1Variant3,
      _property1Variant2 && styles.allTimeProperty1Variant2,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <Text style={$styles.week} testID="2754:1047">
        {`Week`}
      </Text>
      <Text style={$styles.month} testID="2754:1048">
        {`Month`}
      </Text>
      <Text style={$styles.allTime} testID="2754:1049">
        {`All Time`}
      </Text>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    flexDirection: 'row',
    width: 255,
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  week: {
    width: 49,
    height: 15,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(0, 0, 0, 1)',
    textAlign: 'center',
    fontFamily: 'Inter',
    fontSize: 15,
    fontStyle: 'normal',
    fontWeight: '400',
  },
  weekProperty1Variant3: {
    textDecorationLine: 'underline',
  },
  month: {
    width: 49,
    height: 15,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(0, 0, 0, 1)',
    textAlign: 'center',
    fontFamily: 'Inter',
    fontSize: 15,
    fontStyle: 'normal',
    fontWeight: '400',
  },
  monthProperty1Variant2: {
    textDecorationLine: 'underline',
  },
  allTime: {
    width: 63,
    height: 15,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(0, 0, 0, 1)',
    textAlign: 'center',
    fontFamily: 'Inter',
    fontSize: 15,
    fontStyle: 'normal',
    fontWeight: '400',
    textDecorationLine: 'underline',
  },
  allTimeProperty1Variant3: {
    textDecorationLine: 'unset',
  },
  allTimeProperty1Variant2: {
    textDecorationLine: 'unset',
  },
}));
