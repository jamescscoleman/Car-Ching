import React from 'react';
import {Text} from 'react-native';
import {useStyles, createStyles} from 'styles';

export interface PhoneUseProps {
  property1: 'Default' | 'Variant3',
  testID?: string,
}

export function PhoneUse(props: PhoneUseProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant3 = props.property1 === 'Variant3';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant3 && styles.rootProperty1Variant3,
    ],
    rectangle4131: [
      styles.rectangle4131,
      _property1Variant3 && styles.rectangle4131Property1Variant3,
    ],
    rectangle4137: [
      styles.rectangle4137,
      _property1Variant3 && styles.rectangle4137Property1Variant3,
    ],
    tappingTextingOrSwipingContinuouslyWhileDriving: [
      styles.tappingTextingOrSwipingContinuouslyWhileDriving,
      _property1Variant3 && styles.tappingTextingOrSwipingContinuouslyWhileDrivingProperty1Variant3,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <View style={$styles.rectangle4131} testID="1789:2606"/>
      <View style={$styles.rectangle4137} testID="1789:2607"/>
      <Text style={styles.excellentPhoneUse} testID="1789:2616">
        {`Excellent
Phone Use`}
      </Text>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 151,
    height: 54,
    flexShrink: 0,
  },
  rectangle4131: {
    width: 151,
    height: 54,
    flexShrink: 0,
    borderRadius: 7,
    backgroundColor: 'rgba(225, 232, 249, 1)',
  },
  rectangle4137: {
    width: 9,
    height: 54,
    flexShrink: 0,
    borderRadius: 3,
    backgroundColor: 'rgba(0, 130, 85, 1)',
  },
  excellentPhoneUse: {
    width: 142,
    height: 54,
    flexShrink: 0,
    color: 'rgba(120, 112, 112, 1)',
    textAlign: 'center',
    fontFamily: 'Roboto',
    fontSize: 16,
    fontStyle: 'normal',
    fontWeight: '400',
    lineHeight: 23,
    letterSpacing: 0.5,
  },
}));
