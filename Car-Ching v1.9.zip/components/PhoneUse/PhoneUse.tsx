import React from 'react';
import {Text} from 'react-native';
import {useStyles, createStyles} from 'styles';

export interface PhoneUseProps {
  property1: 'Default' | 'Variant2',
  testID?: string,
}

export function PhoneUse(props: PhoneUseProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant2 = props.property1 === 'Variant2';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant2 && styles.rootProperty1Variant2,
    ],
    rectangle4131: [
      styles.rectangle4131,
      _property1Variant2 && styles.rectangle4131Property1Variant2,
    ],
    rectangle4137: [
      styles.rectangle4137,
      _property1Variant2 && styles.rectangle4137Property1Variant2,
    ],
    tappingTextingOrSwipingContinuouslyWhileDriving: [
      styles.tappingTextingOrSwipingContinuouslyWhileDriving,
      _property1Variant2 && styles.tappingTextingOrSwipingContinuouslyWhileDrivingProperty1Variant2,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <View style={$styles.rectangle4131} testID="2500:868"/>
      <View style={$styles.rectangle4137} testID="2500:869"/>
      <Text style={styles.excellentPhoneUse} testID="2500:870">
        {`Phone Use`}
      </Text>
      <Text style={styles.excellent} testID="2500:853">
        {`Excellent`}
      </Text>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 318,
    height: 54,
    flexShrink: 0,
    borderRadius: 15,
  },
  rectangle4131: {
    width: 318,
    height: 54,
    flexShrink: 0,
    borderRadius: 7,
    backgroundColor: 'rgba(225, 232, 249, 1)',
  },
  rectangle4137: {
    width: 18.954,
    height: 54,
    flexShrink: 0,
    borderRadius: 7,
    backgroundColor: 'rgba(0, 130, 85, 1)',
  },
  excellentPhoneUse: {
    width: 299.04599,
    height: 54,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(120, 112, 112, 1)',
    fontFamily: 'Roboto',
    fontSize: 16,
    fontStyle: 'normal',
    fontWeight: '400',
    lineHeight: 23,
    letterSpacing: 0.5,
  },
  excellent: {
    width: 98,
    height: 54,
    flexDirection: 'column',
    justifyContent: 'center',
    flexShrink: 0,
    color: 'rgba(120, 112, 112, 1)',
    textAlign: 'center',
    fontFamily: 'Roboto',
    fontSize: 16,
    fontStyle: 'normal',
    fontWeight: '400',
    lineHeight: 23,
    letterSpacing: 0.5,
  },
}));
