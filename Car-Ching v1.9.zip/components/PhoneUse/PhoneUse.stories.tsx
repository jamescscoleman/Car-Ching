import {PhoneUse as Component} from './PhoneUse';
import type {StoryObj, Meta} from '@storybook/react';

type Story = StoryObj<typeof Component>;

const meta: Meta<typeof Component> = {
  title: 'PhoneUse',
  component: Component,
};

export const Default: Story = {
  args: {
    property1: 'Default',
  },
};

export const Variant3: Story = {
  args: {
    property1: 'Variant3',
  },
};

export default meta;
