import React from 'react';
import {View} from 'react-native';
import {useStyles, createStyles} from 'styles';
import Icon from 'assets/vectors/Icon.svg';

export interface CloseProps {
  testID?: string,
}

export function Close(props: CloseProps) {
  const {styles} = useStyles(stylesheet);

  return (
    <View style={styles.root} testID={props.testID}>
      <Icon/>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    width: 32,
    height: 32,
    flexShrink: 0,
    opacity: 0.4,
  },
}));
