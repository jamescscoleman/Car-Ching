import {Close as Component} from './Close';
import type {StoryObj, Meta} from '@storybook/react';

type Story = StoryObj<typeof Component>;

const meta: Meta<typeof Component> = {
  title: 'close',
  component: Component,
};

export const Close: Story = {
  // ...
};

export default meta;
