import React from 'react';
import {View, Text} from 'react-native';
import {useStyles, createStyles} from 'styles';

export interface InviteFriendsToggleProps {
  property1: 'Default' | 'Variant2',
  testID?: string,
}

export function InviteFriendsToggle(props: InviteFriendsToggleProps) {
  const {styles} = useStyles(stylesheet);

  const _property1Variant2 = props.property1 === 'Variant2';

  const $styles = React.useMemo(() => ({
    root: [
      styles.root,
      _property1Variant2 && styles.rootProperty1Variant2,
    ],
    joined: [
      styles.joined,
      _property1Variant2 && styles.joinedProperty1Variant2,
    ],
    frame5945: [
      styles.frame5945,
      _property1Variant2 && styles.frame5945Property1Variant2,
    ],
  }), [styles, props.property1]);

  return (
    <View style={$styles.root} testID={props.testID}>
      <View style={$styles.frame5945} testID="1738:1174">
        <Text style={styles.get5} testID="1738:1175">
          {`Get $5`}
        </Text>
      </View>
    </View>
  );
}

const stylesheet = createStyles(theme => ({
  root: {
    flexDirection: 'row',
    width: 75,
    height: 35,
    padding: 12,
    justifyContent: 'center',
    alignItems: 'center',
    rowGap: 10,
    columnGap: 10,
    flexShrink: 0,
    borderRadius: 16,
    backgroundColor: 'rgba(8, 210, 56, 1)',
  },
  rootProperty1Variant2: {
    backgroundColor: 'rgba(220, 220, 220, 1)',
  },
  get5: {
    color: 'rgba(5, 21, 50, 1)',
    textAlign: 'center',
    fontFamily: 'Open Sans',
    fontSize: 12,
    fontStyle: 'normal',
    fontWeight: '700',
  },
  frame5945: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    rowGap: 10,
    columnGap: 10,
  },
}));
